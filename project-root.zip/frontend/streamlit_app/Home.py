import streamlit as st
from utils.api_client import get_hello

st.title("Energy Visualization Dashboard")

if st.button("Fetch greeting from backend"):
    result = get_hello()
    st.write(result)
