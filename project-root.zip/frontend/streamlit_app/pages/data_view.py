import streamlit as st
from components.chart_area import render_chart

st.header("Data View")
render_chart()
