class Settings:
    APP_NAME = "Energy Visualization"
    VERSION = "0.1.0"

settings = Settings()
