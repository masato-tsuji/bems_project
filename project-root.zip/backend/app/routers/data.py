from fastapi import APIRouter
from ..services.data_service import get_sample_data

router = APIRouter(prefix="/data", tags=["data"])

@router.get("/sample")
async def sample():
    return get_sample_data()
