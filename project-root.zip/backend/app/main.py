from fastapi import FastAPI
from .routers import data, auth

app = FastAPI(title="Energy Backend API")

app.include_router(data.router)
app.include_router(auth.router)

@app.get("/hello")
async def hello():
    return {"message": "Hello from FastAPI backend!"}
