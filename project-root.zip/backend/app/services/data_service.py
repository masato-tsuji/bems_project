def get_sample_data():
    return {"data": [1,2,3,4,5]}
